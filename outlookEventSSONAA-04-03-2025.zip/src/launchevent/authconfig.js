export const auth = {
  clientId: "6f844b07-cb34-474d-bc8c-2a50f3e6655a",
  authority: "https://login.microsoftonline.com/common",
};
