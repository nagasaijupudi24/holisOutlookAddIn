export const auth = {
  clientId: "3fe55fdd-4659-449d-a944-a2b96bd55c33",
  authority: "https://login.microsoftonline.com/common",
};
