/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable prettier/prettier */
/*
 * Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
 * See LICENSE in the project root for license information.
 */

/* global document, console, fetch, Office */

import { createNestablePublicClientApplication } from "@azure/msal-browser";
import { auth } from "../launchevent/authconfig";

const sideloadMsg = document.getElementById("sideload-msg");
// const signInButton = document.getElementById("btnSignIn");
const itemSubject = document.getElementById("item-subject");



let pca = undefined;
let isPCAInitialized = false;

// Sample JSON with projects and tasks
const projectTasksMap = {
  "Internet Explorer": ["ie1", "ie2", "ie3"],
  "Firefox": ["firefox1", "firefox2"],
  "Chrome": ["chrome1", "chrome2", "chrome3"],
  "Opera": ["opera1", "opera2"],
  "Safari": ["safari1", "safari2"]
};

// Function to populate the Project datalist
const populateProjects = () => {
  const projectInput = document.getElementById("projectInput");
  const projectsDatalist = document.getElementById("projects");

  // Clear the existing options
  projectsDatalist.innerHTML = "";

  // Add the options dynamically from the projectTasksMap keys (project names)
  Object.keys(projectTasksMap).forEach(project => {
      const option = document.createElement("option");
      option.value = project;
      projectsDatalist.appendChild(option);
  });
};

// Function to populate the Project Tasks datalist based on selected project
const populateTasks = (project) => {
  const projectTaskInput = document.getElementById("projectTaskInput");
  const projectsTasksDatalist = document.getElementById("projectsTasks");

  // Clear the previous tasks
  projectsTasksDatalist.innerHTML = "";

  // Add tasks if project exists
  if (projectTasksMap[project]) {
      projectTasksMap[project].forEach(task => {
          const option = document.createElement("option");
          option.value = task;
          projectsTasksDatalist.appendChild(option);
      });
      projectTaskInput.disabled = false;  // Enable the task input
  } else {
      projectTaskInput.disabled = true;  // Disable if no tasks available
  }
};

// Event listener to populate project tasks when a project is selected
document.getElementById("projectInput").addEventListener("input", function () {
  const selectedProject = this.value;
  populateTasks(selectedProject);
});

// Initially populate the projects datalist when the page loads
populateProjects();






Office.onReady(async (info) => {
  if (info.host === Office.HostType.Outlook) {
    console.log(projectTasksMap)
    // Project type toggle
    document.querySelectorAll(".toggle-btn").forEach((button) => {
        button.addEventListener('click', () => {
          document.querySelectorAll('.toggle-btn').forEach(btn => btn.classList.remove('active'));
          button.classList.add('active');
        });
      });
  
      // Save & Close Button  
      document.getElementById('insertTimeEntry').addEventListener('click', () => {
        console.log("Save & Close button clicked");
      });
  
      // Cancel Button  
      document.getElementById('closePane').addEventListener('click', () => {
        console.log("Cancel button clicked");
      });

      
     
    // sideloadMsg.style.display = "none";
    document.getElementById("app-body").style.display = "flex";
    // signInButton.onclick = signInUser;
    // Initialize the public client application.
    try {
      pca = await createNestablePublicClientApplication({
        auth: auth,
      });
      isPCAInitialized = true;
      signInUser()
    } catch (error) {
      // All console.log statements write to the runtime log. For more information, see https://learn.microsoft.com/office/dev/add-ins/testing/runtime-logging
      console.log(`Error creating pca: ${error}`);
    }


    
  }
});

/**
 * Signs in the user using NAA and SSO auth flow. If successful, displays the user's name in the task pane.
 */
async function signInUser() {
  console.log("signInUser function called automatically")
  // Check that PCA initialized correctly in Office.onReady().
  if (!isPCAInitialized) {
    // itemSubject.innerText = "Can't sign in because the PCA could not be initialized. See console logs for details.";
    console.log("Can't sign in because the PCA could not be initialized. See console logs for details.");
    return;
  }

  // Specify minimum scopes needed for the access token.
  const tokenRequest = {
    scopes: ["User.Read","https://org6fd96009.crm8.dynamics.com/user_impersonation"]
  };
  let accessToken = null;
  try {
    const authResult = await pca.acquireTokenSilent(tokenRequest);
    accessToken = authResult.accessToken;
    console.log("Acquired token silently.");
  } catch (error) {
    console.log(`Unable to acquire token silently: ${error}`);
  }
  if (accessToken === null) {
    // If silently acquiring the token fails, send an interactive request via popup.
    try {
      const authResult = await pca.acquireTokenPopup(tokenRequest);
      accessToken = authResult.accessToken;
      console.log("Acquired token interactively.");
    } catch (popupError) {
      // Failed to acquire the token with the popup.
      console.log(`Unable to acquire token interactively: ${popupError}`);
    }
  }

  // Log error if both silent and popup requests failed.
  if (accessToken === null) {
    console.error("Unable to acquire access token.");
    return;
  }

  // Call the Microsoft Graph API with the access token.
  const response = await fetch(`https://org6fd96009.crm8.dynamics.com/api/data/v9.2/cr336_projects`, {
    headers: { Authorization: accessToken },
  });

  if (response.ok) {
    // Get the user name from response JSON.
    
    const data = await response.json();
    if (data){
      console.log(data)

    }
    
    const name = data.displayName;

    if (itemSubject) {
      // itemSubject.innerText = "You are now signed in as " + name + ".";
      console.log(name, "Name");
    }
  } else {
    const errorText = await response.text();
    console.log("Microsoft Graph call failed - error text: " + errorText);
  }
}
