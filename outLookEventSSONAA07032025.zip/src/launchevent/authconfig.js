export const auth = {
  clientId: "85ed8118-0d07-4915-9710-6202f07c91eb",
  authority: "https://login.microsoftonline.com/common",
};
