/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable prettier/prettier */
/*
 * Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
 * See LICENSE in the project root for license information.
 */

/* global document, console, fetch, Office */

import { createNestablePublicClientApplication } from "@azure/msal-browser";
import { auth } from "../launchevent/authconfig";

const sideloadMsg = document.getElementById("sideload-msg");
// const signInButton = document.getElementById("btnSignIn");
const itemSubject = document.getElementById("item-subject");



let pca = undefined;
let isPCAInitialized = false;

// Sample JSON with projects and tasks
const projectTasksMap = {
  "Internet Explorer": ["ie1", "ie2", "ie3"],
  "Firefox": ["firefox1", "firefox2"],
  "Chrome": ["chrome1", "chrome2", "chrome3"],
  "Opera": ["opera1", "opera2"],
  "Safari": ["safari1", "safari2"]
};

// Function to populate the Project datalist
const populateProjects = () => {
  const projectInput = document.getElementById("projectInput");
  const projectsDatalist = document.getElementById("projects");

  // Clear the existing options
  projectsDatalist.innerHTML = "";

  // Add the options dynamically from the projectTasksMap keys (project names)
  Object.keys(projectTasksMap).forEach(project => {
      const option = document.createElement("option");
      option.value = project;
      projectsDatalist.appendChild(option);
  });
};

// Function to populate the Project Tasks datalist based on selected project
const populateTasks = (project) => {
  const projectTaskInput = document.getElementById("projectTaskInput");
  const projectsTasksDatalist = document.getElementById("projectsTasks");

  // Clear the previous tasks
  projectsTasksDatalist.innerHTML = "";

  // Add tasks if project exists
  if (projectTasksMap[project]) {
      projectTasksMap[project].forEach(task => {
          const option = document.createElement("option");
          option.value = task;
          projectsTasksDatalist.appendChild(option);
      });
      projectTaskInput.disabled = false;  // Enable the task input
  } else {
      projectTaskInput.disabled = true;  // Disable if no tasks available
  }
};

// Event listener to populate project tasks when a project is selected
document.getElementById("projectInput").addEventListener("input", function () {
  const selectedProject = this.value;
  populateTasks(selectedProject);
});

// Initially populate the projects datalist when the page loads
populateProjects();






Office.onReady(async (info) => {
  if (info.host === Office.HostType.Outlook) {
      console.log(projectTasksMap);

      // Project type toggle
      document.querySelectorAll(".toggle-btn").forEach((button) => {
          button.addEventListener("click", () => {
              document.querySelectorAll(".toggle-btn").forEach((btn) => btn.classList.remove("active"));
              button.classList.add("active");
          });
      });

      // Save & Close Button
      document.getElementById("insertTimeEntry").addEventListener("click", () => {
          console.log("Save & Close button clicked");
      });

      // Cancel Button
      document.getElementById("closePane").addEventListener("click", () => {
          console.log("Cancel button clicked");
      });

      // Show app body
      document.getElementById("app-body").style.display = "flex";

      // Initialize the public client application
      try {
          pca = await createNestablePublicClientApplication({
              auth: auth,
          });
          isPCAInitialized = true;
          signInUser()
      } catch (error) {
          console.log(`Error creating pca: ${error}`);
      }

      // Check if the current item is an Outlook event
      // Check if the current item is an Outlook event
      const item = Office.context.mailbox.item;
      if (item && item.itemType === Office.MailboxEnums.ItemType.Appointment) {
          setEventDetails(item);
      } else {
          console.log("This is not a calendar event.");
      }
  }
});



// Function to fetch event details and assign them to the input fields
function setEventDetails(item) {
    // Fetch event body
    item.body.getAsync(Office.CoercionType.Html, (result) => {
      if (result.status === Office.AsyncResultStatus.Succeeded) {
          const eventBodyHtml = result.value;
          const descriptionField = document.querySelector(".description-field");

          // Display the HTML content inside the description field
          descriptionField.innerHTML = eventBodyHtml;
          descriptionField.disabled = true; // Disable after assignment
      } else {
          console.error("Error retrieving event body:", result.error.message);
      }
  });

    // Fetch event start date and duration
    item.start.getAsync((startResult) => {
        if (startResult.status === Office.AsyncResultStatus.Succeeded) {
            const startTime = new Date(startResult.value);
            const formattedDate = startTime.toISOString().split("T")[0]; // Convert to YYYY-MM-DD format
            // Use custom class name alongside Fluent UI for event date field
            document.querySelector(".event-date").value = formattedDate;
            document.querySelector(".event-date").disabled = true; // Disable after assignment

            item.end.getAsync((endResult) => {
                if (endResult.status === Office.AsyncResultStatus.Succeeded) {
                    const endTime = new Date(endResult.value);
                    const durationInHours = (endTime - startTime) / (1000 * 60 * 60); // Convert milliseconds to hours
                    // Use custom class name alongside Fluent UI for event duration field
                    document.querySelector(".event-duration").value = durationInHours;
                    document.querySelector(".event-duration").disabled = true; // Disable after assignment
                } else {
                    console.error("Error retrieving end date:", endResult.error.message);
                }
            });
        } else {
            console.error("Error retrieving start date:", startResult.error.message);
        }
    });
}

// Event listener to update the start date when the user changes it
document.querySelector(".event-date").addEventListener("change", (event) => {
    const newStartDate = new Date(event.target.value);
    const item = Office.context.mailbox.item;

    // Update the start date of the event
    item.start.setAsync(newStartDate, { asyncContext: "start-date" }, (result) => {
        if (result.status === Office.AsyncResultStatus.Succeeded) {
            console.log("Start date updated successfully");
        } else {
            console.error("Error updating start date:", result.error.message);
        }
    });
});

// Event listener to update the duration when the user changes it
document.querySelector(".event-duration").addEventListener("change", (event) => {
    const newDuration = parseFloat(event.target.value);
    const item = Office.context.mailbox.item;

    // Calculate the new end date based on the new duration
    item.start.getAsync((startResult) => {
        if (startResult.status === Office.AsyncResultStatus.Succeeded) {
            const startTime = new Date(startResult.value);
            const newEndDate = new Date(startTime.getTime() + newDuration * 60 * 60 * 1000); // Add duration in hours

            // Update the end date of the event
            item.end.setAsync(newEndDate, { asyncContext: "end-date" }, (result) => {
                if (result.status === Office.AsyncResultStatus.Succeeded) {
                    console.log("End date updated successfully");
                } else {
                    console.error("Error updating end date:", result.error.message);
                }
            });
        } else {
            console.error("Error retrieving start date for duration update:", startResult.error.message);
        }
    });
});



/**
 * Signs in the user using NAA and SSO auth flow. If successful, displays the user's name in the task pane.
 */
async function signInUser() {
  console.log("signInUser function called automatically");

  if (!isPCAInitialized) {
    console.log("PCA not initialized. Check PCA configuration.");
    return;
  }

  // Use the specific Dynamics CRM resource URL as the scope
  const tokenRequest = {
    scopes: ["https://hollis-projectops-dev-01.api.crm4.dynamics.com/user_impersonation"]
  };

  let accessToken = null;
  try {
    const authResult = await pca.acquireTokenSilent(tokenRequest);
    accessToken = authResult.accessToken;
    console.log("Token acquired silently:", accessToken.substring(0, 20) + "..."); // Log partial token for debugging
  } catch (error) {
    console.log("Silent token acquisition failed:", error);
  }

  if (accessToken === null) {
    try {
      const authResult = await pca.acquireTokenPopup(tokenRequest);
      accessToken = authResult.accessToken;
      console.log("Token acquired interactively:", accessToken.substring(0, 20) + "...");
    } catch (popupError) {
      console.log("Interactive token acquisition failed:", popupError);
      return;
    }
  }

  if (accessToken === null) {
    console.error("Failed to acquire access token.");
    return;
  }

  // Fetch projects data
  try {
    console.log("Attempting to fetch projects with token...");
    const projectsResponse = await fetch("https://hollis-projectops-dev-01.api.crm4.dynamics.com/api/data/v9.2/msdyn_projects", {
      method: "GET",
      headers: { 
        Authorization: `Bearer ${accessToken}`,
       
      },
    });

    if (projectsResponse.ok) {
      const projectsData = await projectsResponse.json();
      console.log("Projects data retrieved successfully:", projectsData);
      if (itemSubject) {
        console.log(`Number of projects retrieved: ${projectsData.value?.length || 0}`);
      }
    } else {
      const errorText = await projectsResponse.text();
      throw new Error(`Projects fetch failed: ${errorText}`);
    }

  } catch (error) {
    console.error("Dynamics CRM API call failed:", error);
  }
}
