export const auth = {
  // clientId: "85ed8118-0d07-4915-9710-6202f07c91eb", //Holis client Id
  clientId: "85ed8118-0d07-4915-9710-6202f07c91eb", //Xencia client Id

  authority: "https://login.microsoftonline.com/c957560e-8fc9-444a-9cde-bfd3129e36ad",
};
